This skin was made by lucas papaya's owner, aka un_designer on http://forums.precentral.net.

Feel free to use and share.

Say hi or thank if you like it.

palm pre is cool.

