var PrefsAssistant = Class.create({
	initialize: function(phonePrefs, rejectedPrefs, notificationPrefs) {
		this.phonePrefs = phonePrefs;
		this.rejectedPrefs = rejectedPrefs;
		this.notificationPrefs = notificationPrefs;
	},
	
	setup: function() {
		this.controller.document.body.className = "prefs";

		this.controller.setInitialFocusedElement(null); 

		if(this.rejectedPrefs.rejectAction != "autoreply") {
			this.controller.get("RejectedCallRow").addClassName('last');
			this.controller.get("RejectedTextRow").hide();
		}
	
		this.modelMatchContacts = { value: true, disabled: false };

		this.controller.setupWidget('MatchContacts', 
			{falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelMatchContacts);

		this.controller.listen(this.controller.get("MatchContacts"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesstartView = [
			{label: $L("No Default View"), value: "default"},
			{label: $L("Dialpad"), value: "dialpad"},
			{label: $L("Call Log"), value: "calllog"},
			{label: $L("Favorites"), value: "favorites"} ];

		this.modelstartView = {value: this.phonePrefs.startView, disabled: false};

		this.controller.setupWidget("DefaultView", {
			label: $L("Default View"),
			labelPlacement: "left", 							
			choices: this.choicesstartView},
			this.modelstartView);

		this.controller.listen(this.controller.get("DefaultView"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesOnCallView = [
			{label: $L("Contact"), value: "contact"},
			{label: $L("Keypad"), value: "keypad"} ];

		this.modelOnCallView = {value: this.phonePrefs.onCallView, disabled: false};

		this.controller.setupWidget("OnCallView", {
			label: $L("On Call View"),
			labelPlacement: "left", 							
			choices: this.choicesOnCallView},
			this.modelOnCallView);

		this.controller.listen(this.controller.get("OnCallView"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.modelCloseAfter = { value: this.phonePrefs.closeApp, disabled: false };

		this.controller.setupWidget('CloseAfter', 
			{falseLabel: $L("No"), trueLabel: $L("Yes")},
		   this.modelCloseAfter);

		this.controller.listen(this.controller.get("CloseAfter"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesSliderOpened = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Answer Call"), value: "answer"},
			{label: $L("Speakerphone"), value: "speaker"} ];

		this.modelSliderOpened = {value: this.phonePrefs.sliderOpened, disabled: false};

		this.controller.setupWidget("SliderOpened", {
			label: $L("Slider Opened"),
			labelPlacement: "left", 							
			choices: this.choicesSliderOpened},
			this.modelSliderOpened);

		this.controller.listen(this.controller.get("SliderOpened"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesSliderClosed = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Hangup Call"), value: "hangup"} ];

		this.modelSliderClosed = {value: this.phonePrefs.sliderClosed, disabled: false};

		this.controller.setupWidget("SliderClosed", {
			label: $L("Slider Closed"),
			labelPlacement: "left", 							
			choices: this.choicesSliderClosed},
			this.modelSliderClosed);

		this.controller.listen(this.controller.get("SliderClosed"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesPowerButton = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Hangup Call"), value: "hangup"} ];

		this.modelPowerButton = {value: this.phonePrefs.powerButton, disabled: false};

		this.controller.setupWidget("PowerButton", {
			label: $L("Power Button"),
			labelPlacement: "left", 							
			choices: this.choicesPowerButton},
			this.modelPowerButton);

		this.controller.listen(this.controller.get("PowerButton"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesAutoDialing = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Start Call"), value: "call"} ];

		this.modelAutoDialing = {value: this.phonePrefs.autoDialing, disabled: false};

		this.controller.setupWidget("AutoDialing", {
			label: $L("On Dial Select"),
			labelPlacement: "left", 							
			choices: this.choicesAutoDialing},
			this.modelAutoDialing);

		this.controller.listen(this.controller.get("AutoDialing"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesTouchstoneRemove = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Answer Call"), value: "answer"} ];

		this.modelTouchstoneRemove = {value: this.phonePrefs.removedFromTS, disabled: false};

		this.controller.setupWidget("TSAutoAnswer", {
			label: $L("On TS Removal"),
			labelPlacement: "left", 							
			choices: this.choicesTouchstoneRemove},
			this.modelTouchstoneRemove);

		this.controller.listen(this.controller.get("TSAutoAnswer"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
			
		this.choicesProximityAction = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Change Audio"), value: "change"} ];

		this.modelProximityAction = {value: this.phonePrefs.proximityAction, disabled: false};

		this.controller.setupWidget("ProximityAction", {
			label: $L("On Proximity"),
			labelPlacement: "left", 							
			choices: this.choicesProximityAction},
			this.modelProximityAction);

		this.controller.listen(this.controller.get("ProximityAction"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));

		this.choicesRejectedCall = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Send SMS Reply"), value: "autoreply"} ];

		this.modelRejectedCall = {value: this.rejectedPrefs.rejectAction, disabled: false};

		this.controller.setupWidget("RejectedCall", {
			label: $L("On Call Reject"),
			labelPlacement: "left", 							
			choices: this.choicesRejectedCall},
			this.modelRejectedCall);

		this.controller.listen(this.controller.get("RejectedCall"), Mojo.Event.propertyChange, 
			this.saveRejectedPrefs.bind(this));
		
		this.modelRejectedText = {value: this.rejectedPrefs.rejectTemplate, disabled: false};

		this.controller.setupWidget("RejectedText", {'hintText': $L("Template text for auto reply..."), 
		'multiline': true, 'enterSubmits': false, 'autoFocus': false}, this.modelRejectedText); 

		this.controller.listen(this.controller.get("RejectedText"), Mojo.Event.propertyChange, 
			this.saveRejectedPrefs.bind(this));

		this.choicesNotificationRepeat = [
			{label: $L("Disabled"), value: 0},
			{label: $L("Every 2 minutes"), value: 120},
			{label: $L("Every 5 minutes"), value: 300},
			{label: $L("Every 15 minutes"), value: 900},
			{label: $L("Every 30 minutes"), value: 1800},
			{label: $L("Every 60 minutes"), value: 3600} ];

		this.modelNotificationBlink = { value: this.notificationPrefs.notificationBlink, disabled: false };
		
		this.controller.setupWidget('NotificationBlink', 
			{falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelNotificationBlink);

		this.controller.listen(this.controller.get("NotificationBlink"), Mojo.Event.propertyChange, 
			this.saveNotificationPrefs.bind(this));
			
		this.modelNotificationRepeat = {value: this.notificationPrefs.repeatInterval, disabled: false};

		this.controller.setupWidget("NotificationRepeat", {
			label: $L("Repeat"),
			labelPlacement: "left", 							
			choices: this.choicesNotificationRepeat},
			this.modelNotificationRepeat);

		this.controller.listen(this.controller.get("NotificationRepeat"), Mojo.Event.propertyChange, 
			this.saveNotificationPrefs.bind(this));

		this.choicesNotificationTimes = [
			{label: $L("Infinite"), value: 999},
			{label: $L("Repeat 3 times"), value: 3},
			{label: $L("Repeat 5 times"), value: 5},
			{label: $L("Repeat 10 times"), value: 10},
			{label: $L("Repeat 15 times"), value: 15},
			{label: $L("Repeat 30 times"), value: 30} ];

		this.modelNotificationTimes = {value: this.notificationPrefs.repeatLimit, disabled: false};

		this.controller.setupWidget("NotificationTimes", {
			label: $L("Limitation"),
			labelPlacement: "left", 							
			choices: this.choicesNotificationTimes},
			this.modelNotificationTimes);

		this.controller.listen(this.controller.get("NotificationTimes"), Mojo.Event.propertyChange, 
			this.saveNotificationPrefs.bind(this));

		if(this.modelNotificationRepeat.value == 0) {
			this.controller.get("NotificationRepeatRow").addClassName("last");
			this.controller.get("NotificationTimesRow").hide();
		}

		this.modelUnknownContacts = {label: $L("Unknown Contacts Notification")};

		this.controller.setupWidget("UnknownContacts", {}, this.modelUnknownContacts);

		this.controller.listen(this.controller.get("UnknownContacts"), Mojo.Event.tap, 
			this.openUnknownContacts.bind(this));

		this.getPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'getPreferences', parameters: {'keys': ["showcontactmatch"]},
			onSuccess: function(response) {
				if(response.showcontactmatch != undefined) {
					this.modelMatchContacts.value = response.showcontactmatch;
		
					this.controller.modelChanged(this.modelMatchContacts, this);
				}	
			}.bind(this) });
	},

	cleanup: function() {
		this.controller.document.body.className = "palm-default";
	},

	openUnknownContacts: function(event) {
		this.controller.serviceRequest('palm://com.palm.applicationManager', {"method": "launch", 
			"parameters": {"id": "com.palm.app.contacts", "params": {"launchType": "editUnknown"}}});
	},

	savePreferences: function(event) {
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {showcontactmatch: this.modelMatchContacts.value}});
	},

	savePhonePrefs: function(event) {
		this.phonePrefs.startView = this.modelstartView.value;
		this.phonePrefs.onCallView = this.modelOnCallView.value;
		this.phonePrefs.closeApp = this.modelCloseAfter.value;
		this.phonePrefs.sliderOpened = this.modelSliderOpened.value;
		this.phonePrefs.sliderClosed = this.modelSliderClosed.value;
		this.phonePrefs.powerButton = this.modelPowerButton.value;
		this.phonePrefs.autoDialing = this.modelAutoDialing.value;
		this.phonePrefs.removedFromTS = this.modelTouchstoneRemove.value;
		this.phonePrefs.proximityAction = this.modelProximityAction.value;

		var cookieContainer = new Mojo.Model.Cookie("phone");

		cookieContainer.put(this.phonePrefs);
	},
	
	saveRejectedPrefs: function(event) {
		if(this.modelRejectedCall.value == "autoreply") {
			this.controller.get("RejectedCallRow").removeClassName('last');
			this.controller.get("RejectedTextRow").show();
		}
		else {
			this.controller.get("RejectedCallRow").addClassName('last');
			this.controller.get("RejectedTextRow").hide();
		}

		this.rejectedPrefs.rejectAction = this.modelRejectedCall.value;
		this.rejectedPrefs.rejectTemplate = this.modelRejectedText.value;

		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {callRejection: this.rejectedPrefs}});
	},
	
	saveNotificationPrefs: function(event) {
		if(this.modelNotificationRepeat.value == 0) {
			this.controller.get("NotificationRepeatRow").addClassName("last");
			this.controller.get("NotificationTimesRow").hide();
		}
		else {
			this.controller.get("NotificationRepeatRow").removeClassName("last");
			this.controller.get("NotificationTimesRow").show();
		}

		this.notificationPrefs.notificationBlink = this.modelNotificationBlink.value;
		this.notificationPrefs.repeatInterval = parseInt(this.modelNotificationRepeat.value);
		this.notificationPrefs.repeatLimit = parseInt(this.modelNotificationTimes.value);

		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {callNotification: this.notificationPrefs}});
	}
});

