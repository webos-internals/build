/*jslint white: false, onevar: false, nomen:false, plusplus: false */
/*globals enyo Messages NetworkRestrictImageView */

enyo.kind({
	name: "PhoneAppPrefs",
	kind: "VFlexBox",
	className: "enyo-bg",

	components: [
		{kind: "RowGroup", caption: $L("APPLICATION"), components: [
			{kind: "ListSelector", value: "default", label: $L("Default View"), name: "defaultViewPref", onChange: "onDefaultViewChanged"},
			{kind: "ListSelector", value: "contact", label: $L("On Call View"), name: "callViewPref", onChange: "onCallViewChanged"},
			{layoutKind: "HFlexLayout", components: [
				{content: $L("Close After Call"), flex: 1},
				{kind: "ToggleButton", name: "closeAfterPref", onChange: "onCloseAfterChanged"}
			]}
		]},
		
		{kind: "RowGroup", caption: $L("SWITCHES"), components: [
			{kind: "ListSelector", value: "answer", label: $L("Slider Opened"), name: "sliderOpenedPref", onChange: "onSliderOpenedChanged"},
			{kind: "ListSelector", value: "hangup", label: $L("Slider Closed"), name: "sliderClosedPref", onChange: "onSliderClosedChanged"},
			{kind: "ListSelector", value: "none", label: $L("Power Button"), name: "powerButtonPref", onChange: "onPowerButtonChanged"}
		]},

		{kind: "RowGroup", caption: $L("AUTOMATION"), components: [
			{kind: "ListSelector", value: "call", label: $L("On Dial Select"), name: "dialSelectPref", onChange: "onDialSelectChanged"},
			{kind: "ListSelector", value: "answer", label: $L("On TS Removal"), name: "tsRemovalPref", onChange: "onTSRemovalChanged"},
			{kind: "ListSelector", value: "none", label: $L("On Proximity"), name: "proximityEventPref", onChange: "onProximityEventChanged"},
			{kind: "ListSelector", value: "none", label: $L("On Call Reject"), name: "callRejectPref", onChange: "onCallRejectChanged"},
			{kind: "Input", value: "", hint: $L("Template text for auto reply..."), name: "autoReplyPref", onchange: "onAutoReplyChanged"}
		]},

		{kind: "RowGroup", caption: $L("NOTIFICATIONS"), components: [
			{layoutKind: "HFlexLayout", components: [
				{content: $L("Blink Notification"), flex: 1},
				{kind: "ToggleButton", name: "blinkNotifyPref", onChange: "onBlinkNotifyChanged"}
			]},
			{kind: "ListSelector", value: 0, label: $L("Repeat"), name: "notifyRepeatPref", onChange: "onNotifyRepeatChanged"},
			{kind: "ListSelector", value: 3, label: $L("Limitation"), name: "notifyLimitPref", onChange: "onNotifyLimitChanged"}
		]},
		
		{kind: "Button", content: $L("Unknown Contacts Notification"),  name: "unknownContactsButton", onclick: "openUnknownContacts"},
		
		{name: "openContactsApp", kind:"PalmService", service:"palm://com.palm.applicationManager/", method: "launch"},
		
		{name: "getAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "getPreferences", onSuccess: "updatePreferences", onFailure: "updatePreferences"},
		{name: "setAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "setPreferences"}
	],
	
	create: function() {
		this.inherited(arguments);

		this.defaultViewPrefItems = [
			{caption: $L("No Default View"), value: "default"}, 
			{caption: $L("Dialpad"), value: "dialpad"},
			{caption: $L("Call Log"), value: "calllog"},
			{caption: $L("Favorites"), value: "favorites"} ];

		this.$.defaultViewPref.setItems(this.defaultViewPrefItems);

		this.callViewPrefItems = [
			{caption: $L("Contact"), value: "contact"}, 
			{caption: $L("Dialpad"), value: "dialpad"} ];

		this.$.callViewPref.setItems(this.callViewPrefItems);

		this.sliderOpenedPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Answer Call"), value: "answer"}, 
			{caption: $L("Speakerphone"), value: "speaker"} ];

		this.$.sliderOpenedPref.setItems(this.sliderOpenedPrefItems);

		this.sliderClosedPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Hangup Call"), value: "hangup"} ];

		this.$.sliderClosedPref.setItems(this.sliderClosedPrefItems);

		this.powerButtonPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Hangup Call"), value: "hangup"} ];

		this.$.powerButtonPref.setItems(this.powerButtonPrefItems);

		this.dialSelectPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Start Call"), value: "call"} ];

		this.$.dialSelectPref.setItems(this.dialSelectPrefItems);

		this.tsRemovalPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Answer Call"), value: "answer"} ];

		this.$.tsRemovalPref.setItems(this.tsRemovalPrefItems);

		this.proximityEventPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Change Audio"), value: "change"} ];

		this.$.proximityEventPref.setItems(this.proximityEventPrefItems);

		this.callRejectPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Send SMS Reply"), value: "autoreply"} ];

		this.$.callRejectPref.setItems(this.callRejectPrefItems);

		this.notifyRepeatPrefItems = [
			{caption: $L("Disabled"), value: 0}, 
			{caption: $L("Every 2 minutes"), value: 120},
			{caption: $L("Every 5 minutes"), value: 300},
			{caption: $L("Every 15 minutes"), value: 900},
			{caption: $L("Every 30 minutes"), value: 1800},
			{caption: $L("Every 60 minutes"), value: 3600} ];

		this.$.notifyRepeatPref.setItems(this.notifyRepeatPrefItems);

		this.notifyLimitPrefItems = [
			{caption: $L("Infinite"), value: 999},
			{caption: $L("Repeat 3 times"), value: 3},
			{caption: $L("Repeat 5 times"), value: 5},
			{caption: $L("Repeat 10 times"), value: 10},
			{caption: $L("Repeat 15 times"), value: 15},
			{caption: $L("Repeat 30 times"), value: 30} ];

		this.$.notifyLimitPref.setItems(this.notifyLimitPrefItems);

		this.loadPreferences();
	},
	
	loadPreferences: function() {
		if((localStorage) && (localStorage["phonePrefs"]))
			this.phonePrefs = enyo.json.parse(localStorage["phonePrefs"]);
		else {
			this.phonePrefs = {
				version: 1,
				closeApp: false,
				startView: "default",
				onCallView: "contact",
				autoDialing: "call",
				powerButton: "none",
				sliderOpened: "answer",
				sliderClosed: "hangup",
				removedFromTS: "answer",
				proximityAction: "none" };
		}

		this.$.defaultViewPref.setValue(this.phonePrefs.startView);
		this.$.callViewPref.setValue(this.phonePrefs.onCallView);
		this.$.closeAfterPref.setState(this.phonePrefs.closeApp);

		this.$.sliderOpenedPref.setValue(this.phonePrefs.sliderOpened);
		this.$.sliderClosedPref.setValue(this.phonePrefs.sliderClosed);
		this.$.powerButtonPref.setValue(this.phonePrefs.powerButton);

		this.$.dialSelectPref.setValue(this.phonePrefs.autoDialing);
		this.$.tsRemovalPref.setValue(this.phonePrefs.removedFromTS);
		this.$.proximityEventPref.setValue(this.phonePrefs.proximityAction);

		this.rejectedPrefs = {
			rejectAction: "none",
			rejectTemplate: "Sorry, I am currently busy and will call you back later..." };
		
		this.notificationPrefs = {
			notificationBlink: true,
			repeatInterval: 0,
			repeatLimit: 3 };

		this.$.getAppPreferences.call({
			keys: ["callRejection", "callNotification"]
		});
	},

	updatePreferences: function(inSender, inResponse) {
		if((inResponse) && (inResponse.returnValue)) {
			if(inResponse.callRejection)
				this.rejectedPrefs = inResponse.callRejection;		

			if(inResponse.callNotification)
				this.notificationPrefs = inResponse.callNotification;
		}
		
		this.$.callRejectPref.setValue(this.rejectedPrefs.rejectAction);
		this.$.autoReplyPref.setValue($L(this.rejectedPrefs.rejectTemplate));

		if(this.rejectedPrefs.rejectAction == "none")
			this.$.autoReplyPref.hide();

		this.$.blinkNotifyPref.setState(this.notificationPrefs.notificationBlink);
		this.$.notifyRepeatPref.setValue(this.notificationPrefs.repeatInterval);
		this.$.notifyLimitPref.setValue(this.notificationPrefs.repeatLimit);	

		if(this.notificationPrefs.repeatInterval == 0)
			this.$.notifyLimitPref.hide();
	},
	
	onDefaultViewChanged: function() {
		this.phonePrefs.startView = this.$.defaultViewPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onCallViewChanged: function() {
		this.phonePrefs.onCallView = this.$.callViewPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onCloseAfterChanged: function() {
		this.phonePrefs.closeApp = this.$.closeAfterPref.getState();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},

	onSliderOpenedChanged: function() {
		this.phonePrefs.sliderOpened = this.$.sliderOpenedPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onSliderClosedChanged: function() {
		this.phonePrefs.sliderClosed = this.$.sliderClosedPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onPowerButtonChanged: function() {
		this.phonePrefs.powerButton = this.$.powerButtonPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},

	onDialSelectChanged: function() {
		this.phonePrefs.autoDialing = this.$.dialSelectPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onTSRemovalChanged: function() {
		this.phonePrefs.removedFromTS = this.$.tsRemovalPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onProximityEventChanged: function() {
		this.phonePrefs.proximityAction = this.$.proximityEventPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onCallRejectChanged: function() {
		this.rejectedPrefs.rejectAction = this.$.callRejectPref.getValue();

		if(this.rejectedPrefs.rejectAction == "none")
			this.$.autoReplyPref.hide();
		else
			this.$.autoReplyPref.show();

		this.$.setAppPreferences.call({ callRejection: this.rejectedPrefs });
	},
	onAutoReplyChanged: function() {
		this.rejectedPrefs.rejectTemplate = this.$.autoReplyPref.getValue();

		this.$.setAppPreferences.call({ callRejection: this.rejectedPrefs });
	},

	onBlinkNotifyChanged: function() {
		this.notificationPrefs.notificationBlink = this.$.blinkNotifyPref.getState();

		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	onNotifyRepeatChanged: function() {
		this.notificationPrefs.repeatInterval = this.$.notifyRepeatPref.getValue();

		if(this.notificationPrefs.repeatInterval == 0)
			this.$.notifyLimitPref.hide();
		else
			this.$.notifyLimitPref.show();

		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	onNotifyLimitChanged: function() {
		this.notificationPrefs.repeatLimit = this.$.notifyLimitPref.getValue();

		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	openUnknownContacts: function() {
		this.$.openContactsApp.call({
			id: "com.palm.app.contacts", params: {	launchType: "editUnknown" }
		});
	}
});

