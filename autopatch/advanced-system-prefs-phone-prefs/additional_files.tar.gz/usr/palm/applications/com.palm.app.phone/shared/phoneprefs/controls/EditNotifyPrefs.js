enyo.kind({
	name: "EditNotifyPrefs",
	kind: "VFlexBox",
	className: "enyo-bg",
	
	events: {
		editNotifyDone: ""
	},
	
	components: [
		{name: "pane", kind:"Pane", flex: 1, components: [
			{name: "main", kind: "Scroller", className: "", components: [
				{ kind: "PageHeader", className: "header", components: [
					{name: "photoImage", kind: "Image", style: "padding-right: 6px;", className: "phone-icon", src: "../shared/phoneprefs/images/header-icon-phone.png"},
					{name: "pageHeader", content: $L("Notification Settings"), className: "phone-header-caption"},
				]},
				{style: "padding: 5px;", components: [
					{kind: "RowGroup", name: "missedCallsPrefs", caption: $L("MISSED CALLS"), components: [
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{content: $L("Use Notification"), style: "padding-top: 8px;", flex: 1},
							{kind: "ToggleButton", name: "visualNotifyPref", onChange: "onVisualNotifyChanged"}
						]},
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{content: $L("Blink Notification"), style: "padding-top: 8px;", flex: 1},
							{kind: "ToggleButton", name: "blinkNotifyPref", onChange: "onBlinkNotifyChanged"}
						]}
					]},
					
					{kind: "RowGroup", name: "notificationPrefs", caption: $L("NOTIFICATION SOUND"), components: [
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{kind: "ListSelector", flex: 1, value: 0, label: $L("Alert"), name: "notifySoundPref", onChange: "onSoundNotifyChanged"},
						]},
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{name: "notifyRingtonePref", flex: 1, content: "Ringtone", style: "padding-bottom: 5px;", onclick: "selectRingtone"}
						]}
					]},
					
					{kind: "RowGroup", name: "repeatNotifyPrefs", caption: $L("NOTIFICATION REPEAT"), components: [
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{kind: "ListSelector", flex: 1, value: 0, label: $L("Repeat"), name: "notifyRepeatPref", onChange: "onNotifyRepeatChanged"},
						]},
						{kind: "Item", layoutKind: "HFlexLayout", components: [
							{kind: "ListSelector", flex: 1, value: 3, label: $L("Limitation"), name: "notifyLimitationPref", onChange: "onNotifyLimitationChanged"}
						]}
					]},
					
					{kind: "Button", style: "padding-bottom: 5px;", content: $L("Unknown Contacts Notification"),  name: "unknownContactsButton", onclick: "openUnknownContacts"},
				]},
			]},
		]},
		
		{name: "ringtonePicker", kind: "FilePicker", fileType: "ringtone", onPickFile: "updateRingtone"},
		
		{name: "accounts", kind: "DBModel.Accounts", onGotAccounts: "updatePhoneAccounts"},
				
		{name: "openContactsApp", kind:"PalmService", service:"palm://com.palm.applicationManager/", method: "launch"},
		
		{name: "getAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "getPreferences", 
			onSuccess: "updatePreferences", onFailure: "updatePreferences"},
		{name: "setAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "setPreferences"}
	],
	
	create: function() {
		this.inherited(arguments);
		
		this.notifySoundPrefItems = [
			{caption: $L("Vibrate"), value: "vibrate"}, 
			{caption: $L("System Sound"), value: "alert"}, 
//			{caption: $L("Ringtone"), value: "ringtone"}, 
			{caption: $L("Mute"), value: "mute"}];
		
		this.$.notifySoundPref.setItems(this.notifySoundPrefItems);
		
		this.notifyRepeatPrefItems = [
			{caption: $L("Disabled"), value: 0}, 
			{caption: $L("Every 2 minutes"), value: 120}, 
			{caption: $L("Every 5 minutes"), value: 300}, 
			{caption: $L("Every 15 minutes"), value: 900}, 
			{caption: $L("Every 30 minutes"), value: 1800}, 
			{caption: $L("Every 60 minutes"), value: 3600} ];
		
		this.$.notifyRepeatPref.setItems(this.notifyRepeatPrefItems);
		
		this.notifyLimitationPrefItems = [
			{caption: $L("Infinite"), value: 999}, 
			{caption: $L("Repeat 3 times"), value: 3}, 
			{caption: $L("Repeat 5 times"), value: 5}, 
			{caption: $L("Repeat 10 times"), value: 10}, 
			{caption: $L("Repeat 15 times"), value: 15}, 
			{caption: $L("Repeat 30 times"), value: 30} ];
		
		this.$.notifyLimitationPref.setItems(this.notifyLimitationPrefItems);
	},
	
	loadPreferences: function(accountId, icon) {
		this.accountId = accountId;
		
		this.$.photoImage.setSrc(icon);
		
		this.notificationPrefs = {
			notificationVisual: true, 
			notificationBlink: true, 
			notificationSound: "alert", 
			ringtoneName: "", 
			ringtonePath: "", 
			repeatInterval: 0, 
			repeatLimitation: 3, 
			phoneAccounts: {}
		};
		
		this.$.getAppPreferences.call({
			keys: ["callNotification"]
		});
	},
	
	updatePreferences: function(inSender, inResponse) {
		if((inResponse) && (inResponse.returnValue) && (inResponse.callNotification)) {
			for(var key in inResponse.callNotification) {
				if(inResponse.callNotification[key] != undefined)
					this.notificationPrefs[key] = inResponse.callNotification[key];
			}
		}
		
		this.$.accounts.getAllAccounts();
	},
	
	updatePhoneAccounts: function(inSender, inResponse) {
		if(inResponse.results) {
			var accounts = [];
			
			inResponse.results.forEach(function(account) {
				var cap = this.$.accounts.getPhoneCapabilityProvider(account);
				
				if((cap) && (cap.serviceName !== "com.palm.telephony")) {
					accounts.push(account._id);
				}
			}, this);
			
			for(var accountId in this.notificationPrefs.phoneAccounts) {
				if(accounts.indexOf(accountId) == -1)
					delete this.notificationPrefs.phoneAccounts[accountId];
			}
			
			this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
		}
		
		this.updatePreferencesUI();
	},
	
	updatePreferencesUI: function() {
		this.accountPrefs = this.notificationPrefs;
		
		if(this.accountId) {
			if(!this.notificationPrefs.phoneAccounts[this.accountId]) {
				this.notificationPrefs.phoneAccounts[this.accountId] = {
					notificationVisual: true, 
					notificationBlink: true, 
					notificationSound: "alert", 
					ringtoneName: "", 
					ringtonePath: "", 
					repeatInterval: 0, 
					repeatLimitation: 3
				};
			}
			
			this.accountPrefs = this.notificationPrefs.phoneAccounts[this.accountId];
		}
		
		this.$.visualNotifyPref.setState(this.accountPrefs.notificationVisual);
		this.$.blinkNotifyPref.setState(this.accountPrefs.notificationBlink);
		
		this.$.notifySoundPref.setValue(this.accountPrefs.notificationSound);
		
		this.$.notifyRepeatPref.setValue(this.accountPrefs.repeatInterval);
		this.$.notifyLimitationPref.setValue(this.accountPrefs.repeatLimitation);
		
		if(this.accountPrefs.notificationVisual == false) {
			this.$.missedCallsPrefs.hideRow(1);
			this.$.notificationPrefs.hide();
			this.$.repeatNotifyPrefs.hide();
		}
		else {
			this.$.missedCallsPrefs.showRow(1);
			this.$.notificationPrefs.show();
			this.$.repeatNotifyPrefs.show();
			
			if(this.accountPrefs.notificationSound == "mute")
				this.$.repeatNotifyPrefs.hide();
			else
				this.$.repeatNotifyPrefs.show();
		}
		
		if(this.accountPrefs.notificationSound != "ringtone")
			this.$.notificationPrefs.hideRow(1);
		else
			this.$.notificationPrefs.showRow(1);
		
		if(this.accountPrefs.repeatInterval == 0)
			this.$.repeatNotifyPrefs.hideRow(1);
		else
			this.$.repeatNotifyPrefs.showRow(1);
	},
	
	onVisualNotifyChanged: function(inSender, inEvent) {
		this.accountPrefs.notificationVisual = this.$.visualNotifyPref.getState();
		
		if(this.accountPrefs.notificationVisual == false) {
			this.$.missedCallsPrefs.hideRow(1);
			this.$.notificationPrefs.hide();
			this.$.repeatNotifyPrefs.hide();
		}
		else {
			this.$.missedCallsPrefs.showRow(1);
			this.$.notificationPrefs.show();
			
			if(this.accountPrefs.notificationSound != "mute")
				this.$.repeatNotifyPrefs.show();
		}
		
		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	
	onBlinkNotifyChanged: function() {
		this.accountPrefs.notificationBlink = this.$.blinkNotifyPref.getState();
		
		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	
	onSoundNotifyChanged: function(inSender, inEvent) {
		this.accountPrefs.notificationSound = this.$.notifySoundPref.getValue();
		
		if(this.accountPrefs.notificationSound == "mute")
			this.$.repeatNotifyPrefs.hide();
		else
			this.$.repeatNotifyPrefs.show();
			
		if(this.accountPrefs.notificationSound != "ringtone")
			this.$.notificationPrefs.hideRow(1);
		else
			this.$.notificationPrefs.showRow(1);
		
		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	
	onNotifyRepeatChanged: function() {
		this.accountPrefs.repeatInterval = this.$.notifyRepeatPref.getValue();
		
		if(this.accountPrefs.repeatInterval == 0)
			this.$.repeatNotifyPrefs.hideRow(1);
		else
			this.$.repeatNotifyPrefs.showRow(1);
		
		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	
	onNotifyLimitationChanged: function() {
		this.accountPrefs.repeatLimitation = this.$.notifyLimitationPref.getValue();
		
		this.$.setAppPreferences.call({ callNotification: this.notificationPrefs });
	},
	
	openUnknownContacts: function() {
		this.$.openContactsApp.call({
			id: "com.palm.app.contacts", params: {	launchType: "editUnknown" }
		});
	},
	
	selectRingtone: function() {
		this.$.ringtonePicker.pickFile();
	},
	
	updateRingtone: function() {
	}
});

