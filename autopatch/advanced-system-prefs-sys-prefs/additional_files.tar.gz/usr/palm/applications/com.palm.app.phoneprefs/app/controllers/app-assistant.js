/* Copyright 2009 Palm, Inc.  All rights reserved. */

function AppAssistant(appController) {
	this.appController = appController;
};

AppAssistant.prototype.handleLaunch = function(params) {
	var appController = Mojo.Controller.getAppController();
	
	var mainScene = function(stageController) {
		stageController.pushScene("main", params);
	};
	
	var stageArgs = {name: "main", lightweight: true};
	
	this.controller.createStageWithCallback(stageArgs,
		mainScene.bind(this), "card");
	
	var request = new Mojo.Service.Request("palm://com.palm.applicationManager", {
		method: 'launch', parameters: {id: "com.palm.app.phone", params: {preferences: true}}
	});
};

function MainAssistant() {
};

MainAssistant.prototype.setup = function() {
	this.controller.window.close();
};

