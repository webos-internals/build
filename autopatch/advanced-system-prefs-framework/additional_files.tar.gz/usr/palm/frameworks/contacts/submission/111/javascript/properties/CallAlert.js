var CallAlert = PropertyBase.create({
	data: [
		{
			dbFieldName: "alert",
			defaultValue: "",
			setterName: "setAlert",
			getterName: "getAlert"
		}
	]
});
