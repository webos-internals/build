var PasswordAssistant = Class.create({
	
	initialize: function(mode, mainAssistant, setFocus) {
		this.mode = mode;
		this.mainAssistant = mainAssistant;
		
		// Ask
		this.enteredPin = '';
		this.firstPinInput = '';
		this.setFocus = setFocus;
		this.settingPassword = false;
		
		// Verify
		this.enteredPassword = '';
		this.passwordVerified = false;	
	},
	
	setup : function() {
		Mojo.Log.info("Password assistant setup ");

		if((this.mode == "askPassword") || (this.mode == "changePassword"))
			this.controller.get('password_confirm').hide();
		else if(this.mode == "enterPassword")
			this.controller.get('password_title').innerHTML = "Enter New Password";		
	
		this.passwordAttributes = {
			textFieldName: "password",
			hintText: "Password...",
			property: 'value',
			multi: false,        
			changeOnKeyPress: true,
			disabled: false,		      
			};

		this.passwordModel = {
			'value' : ''
		};

		this.passwordAttributes2 = {
			textFieldName: "password",
			hintText: "Password Again...",
			property: 'value',
			multi: false,        
			changeOnKeyPress: true,
			disabled: false,	    
			requiresEnterKey: true,
		};

		this.passwordModel2 = {
			'value' : ''
		};

		this.buttonAttributes = {
			disabledProperty: 'disabled'
		},
		 
		this.doneButtonModel = {
			buttonLabel : $L("Done"),
			buttonClass : "affirmative",
			disabled: false
		},
		this.cancelButtonModel = {
			buttonLabel : $L("Cancel"),
			disabled: false
		},
		 
		this.controller.setupWidget('password_text_1', this.passwordAttributes, this.passwordModel);
		this.controller.setupWidget('password_text_2', this.passwordAttributes2, this.passwordModel2);
		
		$('password_text_1').observe(Mojo.Event.propertyChange, this.propertyChanged.bind(this));
		$('password_text_2').observe(Mojo.Event.propertyChange, this.confirmPasswordpropertyChanged.bind(this));
		
		this.controller.setupWidget('done', this.buttonattributes, this.doneButtonModel);
		this.controller.setupWidget('cancel', this.buttonattributes, this.cancelButtonModel);
				
		$('cancel').addEventListener(Mojo.Event.tap, this.cancel.bindAsEventListener(this));
		
		if((this.mode == "askPassword") || (this.mode == "changePassword"))
			$('done').addEventListener(Mojo.Event.tap, this.matchPassword.bindAsEventListener(this));
		else if(this.mode == "enterPassword")
			$('done').addEventListener(Mojo.Event.tap, this.verifyPassword.bindAsEventListener(this));
		
		if(this.mainAssistant.passwordHintText)
			$('passwordhint').innerHTML = this.mainAssistant.passwordHintText;
			
		if(this.mainAssistant.securityPolicy && this.mainAssistant.retriesLeft == 1) {
			$('passworderrortext').innerHTML = $L("Password incorrect. If you enter an incorrect password now your phone will be erased.");
			$('passworderror').show();
		}
	},
	
	activate: function() {
		if(this.setFocus)
			$('password_text_1').mojo.focus();	
	},
	
	cleanup: function() {
		if(this.mode == "askPassword") {
			if(this.passwordVerified === false)
				this.mainAssistant.passwordVerified(false);
		}
		else if(this.mode == "enterPassword") {
			if(this.settingPassword === false)	
				this.mainAssistant.revertChanges();
		}
	},

	matchPassword: function(event) {
		if(!event)
			return;
		event.stop();
		
		if(this.passwordVerified)
			this.verifyPassword(event);
		else
			SystemService.matchDevicePasscode($('password_text_1').mojo.getValue(),this.checkPasswd.bind(this));
	},

	checkPasswd: function(payload) {
		if(!payload)
			return;
				
		if(payload.returnValue === true ) {
			if(this.mainAssistant.securityPolicy) 
				this.mainAssistant.retriesLeft = this.mainAssistant.maxRetries;
			this.passwordVerified = true;		
			Mojo.Log.info("Password Matches!!!");
			
			if(this.mode == "askPassword") {
				this.mainAssistant.passwordVerified(true);

				Mojo.Controller.stageController.popScene();
			}
			else if(this.mode == "changePassword") {
				this.clearFields();

				$('passworderror').hide();

				this.controller.get('password_title').innerHTML = "Enter New Password";		
				
				this.controller.get('password_confirm').show();
			}
		}
		else {
			
			this.clearFields();
			
			if(this.mainAssistant.securityPolicy) {
				this.mainAssistant.retriesLeft = payload.retriesLeft;
				if(payload.retriesLeft === 1) { 
					$('passworderrortext').innerHTML = $L("Password incorrect. If you enter an incorrect password now your phone will be erased.");
				}
				else {
					$('passworderrortext').innerHTML = $L("Password incorrect. ") + Mojo.Format.formatChoice(payload.retriesLeft, 
								$L("##{num} tries remaining."), 
								{num: SystemService.numberToWord(payload.retriesLeft)});
				}
			}
			else 
				$('passworderrortext').innerHTML = $L("Incorrect password.");
			$('passworderror').show();
		}
	},

	verifyPassword: function(event) {
		Event.stop(event);
		
		if($('password_text_1').mojo.getValue() == $('password_text_2').mojo.getValue()) {
			if(this.mainAssistant.securityPolicy) {
				this.settingPassword = true;
				this.doneButtonModel.disabled = true;
				this.cancelButtonModel.disabled = true;
				this.controller.modelChanged(this.doneButtonModel);
				this.controller.modelChanged(this.cancelButtonModel);
				this.setSystemlockPasswordReq = SystemService.setSystemlockValue('password',$('password_text_1').mojo.getValue(), this.handleSetPasswordResponse.bind(this));
			}
			else {
				this.mainAssistant.setPassword($('password_text_2').mojo.getValue());
				Mojo.Controller.stageController.popScene();	
			}		
		}
		else {
			Mojo.Log.info("Password don't Match!!!");
			this.clearFields();
			$('passworderrortext').innerHTML = $L("Passwords do not match.");
			$('passworderror').show();
		}
	},
	
	handleSetPasswordResponse: function(payload) {
		
		this.settingPassword = false;
		this.doneButtonModel.disabled = false;
		this.cancelButtonModel.disabled = false;
		this.controller.modelChanged(this.doneButtonModel);
		this.controller.modelChanged(this.cancelButtonModel);
		
		if(payload.returnValue) {
			this.mainAssistant.passwordAlreadySet($('password_text_1').mojo.getValue());
			Mojo.Controller.stageController.popScene();
		}
		else {
			this.clearFields();
			$('passworderrortext').innerHTML = $L("Password does not match security requirements.");
			$('passworderror').show();
		}
	},
	
	propertyChanged: function(event) {
		if(!event)
			return;

		if(this.mode == "askPassword") {
			if(event && Mojo.Char.isEnterKey(event.originalEvent.keyCode))
				this.matchPassword(event);
		}
		else if(this.mode == "enterPassword") {	
			if($('passworderror').visible())
				$('passworderror').hide();
		}
	},
	
	confirmPasswordpropertyChanged: function(event) {
		if (event && Mojo.Char.isEnterKey(event.originalEvent.keyCode)) {
			this.verifyPassword(event);
		}
	},
		
	cancel: function(event) {
		if(this.mode == "askPassword")
			this.mainAssistant.passwordVerified(false);
		else if(this.mode == "enterPassword")
			this.mainAssistant.setPassword('');
		
		Mojo.Controller.stageController.popScene();
	},
	
	clearFields: function() {
		this.passwordModel.value = '';
		this.passwordModel2.value = '';
		this.controller.modelChanged(this.passwordModel,this);
		this.controller.modelChanged(this.passwordModel2,this);
		
		$('password_text_1').mojo.focus();	
	},
	
	handleCommand: function(event) {
		if(event.type == Mojo.Event.back) {	
			event.stop();
			
			if((this.mode == "enterPassword") && (this.settingPassword == true))
				return;		
				
			this.mainAssistant.revertChanges();
			Mojo.Controller.stageController.popScene();
		}
	}		
	
});

