var MsgRingtone = PropertyBase.create({
	data: [
		{
			dbFieldName: "name",
			defaultValue: "",
			setterName: "setName",
			getterName: "getName"
		}, {
			dbFieldName: "location",
			defaultValue: "",
			setterName: "setLocation",
			getterName: "getLocation"
		}
	]
});
