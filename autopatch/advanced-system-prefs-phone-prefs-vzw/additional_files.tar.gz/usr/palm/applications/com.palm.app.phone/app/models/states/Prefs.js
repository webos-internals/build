//prefs
UIStateMachine.STATES.PrefsState = Class.create(UIStateMachine.STATES.AbstractState, {
	setup: function(phonePrefs, rejectedPrefs, notificationPrefs) {
		this.appController.getStageController(this.machine.STAGE_MAIN).pushScene("prefs",  
			phonePrefs, rejectedPrefs, notificationPrefs);
	},
	cleanup: function() {
		var stageController = this.appController.getStageController(this.machine.STAGE_MAIN);
		if ( stageController && ! this.dontReset ) {
			stageController.popScene();
		}
	},
	event_back: function(commandEvent) {
		this.machine.enter(this.machine.previousState.name);
	},
	event_closed: function() {
		var stageController = this.appController.getStageController(this.machine.STAGE_MAIN);
		if ( stageController && ! this.dontReset ) {
			stageController.popScene();
		}
		this.machine.currentState = this.machine.previousState;	
	},
	event_launch: function(params) {
		this.machine.enter(this.machine.previousState.name);
	},
	event_dial: function(params) {
		this.machine.enter(this.machine.previousState.name);
	},
	event_hangup: function(params) {
		this.machine.enter(this.machine.previousState.name);
	}
});
