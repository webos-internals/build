var PrefsSetupNotificationsAssistant = Class.create({
	initialize: function(messagingPrefs, serviceName, serviceIcon) {
		this.messagingPrefs = messagingPrefs;
		
		this.serviceName = serviceName;
		this.serviceIcon = serviceIcon;

		this.notificationsEnabledChanged = this.notificationsEnabledChanged.bind(this);
		this.notificationBlinkChanged = this.notificationBlinkChanged.bind(this);
		this.notificationSoundChanged = this.notificationSoundChanged.bind(this);
		this.chooseNotificationRingtone = this.chooseNotificationRingtone.bind(this);
		this.notificationRepeatChanged = this.notificationRepeatChanged.bind(this);
		this.notificationLimitChanged = this.notificationLimitChanged.bind(this);
	},
	
	setup: function() {
		if(this.serviceName == undefined)
			var bg = "url(./images/header-icon-messaging.png) center center no-repeat";
		else
			var bg = "url(" + this.serviceIcon + ") center center no-repeat";
		
		this.controller.get('title-icon').style.background = bg;

		this.modelNotificationsEnabled = {value: this.messagingPrefs.getNotificationsEnabled(this.serviceName)};

		this.controller.setupWidget('notificationsEnabled', {}, this.modelNotificationsEnabled);   
		
		this.controller.listen('notificationsEnabled', Mojo.Event.propertyChange, this.notificationsEnabledChanged);	

		if(this.modelNotificationsEnabled.value == true) {
			this.controller.get('notificationsEnabledRow').removeClassName("single");
			this.controller.get('notificationsEnabledRow').addClassName("first");
			this.controller.get('notificationBlinkRow').show();
			this.controller.get('notificationPrefs').show();
		}
		else {
			this.controller.get('notificationBlinkRow').hide();
			this.controller.get('notificationPrefs').hide();
		}
		
		this.modelNotificationBlink = {value: this.messagingPrefs.getNotificationBlink(this.serviceName)};

		this.controller.setupWidget('notificationBlink', {falseLabel: $L("Off"), trueLabel: $L("On")},
			this.modelNotificationBlink);

		this.controller.listen('notificationBlink', Mojo.Event.propertyChange, 
			this.notificationBlinkChanged);		

		this.soundSelections = [
			{label: $L("Vibrate"), value: "vibrate"},
			{label: $L("System Sound"), value: "alert"},
			{label: $L("Ringtone"), value: "ringtone"},
			{label: $L("Mute"), value: "mute"}];
			
		this.modelNotificationSound = {value: this.messagingPrefs.getNotificationSound(this.serviceName)};

		this.controller.setupWidget('notificationSound', {label: $L("Alert"), choices: this.soundSelections},
			this.modelNotificationSound);
		
		this.controller.listen('notificationSound', Mojo.Event.propertyChange, this.notificationSoundChanged);

		if(this.modelNotificationSound.value == "ringtone") {
			this.controller.get('notificationSoundRow').removeClassName("single");
			this.controller.get('notificationSoundRow').addClassName("first");
			this.controller.get('notificationRingtoneRow').show();
		}
		else
			this.controller.get('notificationRingtoneRow').hide();

		if((this.messagingPrefs.getRingtone(this.serviceName).name) &&
			(this.messagingPrefs.getRingtone(this.serviceName).name != ""))
		{
			this.controller.get('notificationRingtone').update(this.messagingPrefs.getRingtone(this.serviceName).name);
		}
		else
			this.controller.get('notificationRingtone').update("");
		
		this.controller.listen('notificationRingtoneRow', Mojo.Event.tap, this.chooseNotificationRingtone);

		this.repeatSelections = [
			{label: $L("Disabled"), value: 0},
			{label: $L("Every 2 minutes"), value: 120},
			{label: $L("Every 5 minutes"), value: 300},
			{label: $L("Every 15 minutes"), value: 900},
			{label: $L("Every 30 minutes"), value: 1800},
			{label: $L("Every 60 minutes"), value: 3600} ];

		this.modelNotificationRepeat = {value: this.messagingPrefs.getRepeatInterval(this.serviceName)};

		this.controller.setupWidget("notificationRepeat", {label: $L("Repeat"), choices: this.repeatSelections},
			this.modelNotificationRepeat);

		this.controller.listen(this.controller.get("notificationRepeat"), Mojo.Event.propertyChange, 
			this.notificationRepeatChanged);

		if(this.modelNotificationRepeat.value == 0) {
			this.controller.get('notificationLimitRow').hide();
		}

		if(this.modelNotificationRepeat.value != 0) {
			this.controller.get('notificationRepeatRow').removeClassName("single");
			this.controller.get('notificationRepeatRow').addClassName("first");
			this.controller.get('notificationLimitRow').show();
		}
		else
			this.controller.get('notificationLimitRow').hide();

		this.limitSelections = [
			{label: $L("Repeat infinitely"), value: 999},
			{label: $L("Repeat 3 times"), value: 3},
			{label: $L("Repeat 5 times"), value: 5},
			{label: $L("Repeat 10 times"), value: 10},
			{label: $L("Repeat 15 times"), value: 15},
			{label: $L("Repeat 30 times"), value: 30} ];

		this.modelNotificationLimit = {value: this.messagingPrefs.getRepeatLimit(this.serviceName)};

		this.controller.setupWidget("notificationLimit", {label: $L("Limitation"), choices: this.limitSelections},
			this.modelNotificationLimit);

		this.controller.listen(this.controller.get("notificationLimit"), Mojo.Event.propertyChange, 
			this.notificationLimitChanged);

		this.modelUnknownContacts = {label: $L("Unknown Contacts Notification")};

		this.controller.setupWidget("unknownContacts", {}, this.modelUnknownContacts);

		this.controller.listen(this.controller.get("unknownContacts"), Mojo.Event.tap, 
			this.openUnknownContacts.bind(this));
	},

	cleanup: function() {
		this.controller.stopListening('notificationsEnabled', Mojo.Event.propertyChange, this.notificationsEnabledChanged);
		this.controller.stopListening('notificationBlink', Mojo.Event.propertyChange, this.notificationBlinkChanged);
		this.controller.stopListening('notificationSound', Mojo.Event.propertyChange, this.notificationSoundChanged);
		this.controller.stopListening('notificationRingtone', Mojo.Event.propertyChange, this.chooseNotificationRingtone);
		this.controller.stopListening('notificationRepeat', Mojo.Event.propertyChange, this.notificationRepeatChanged);
		this.controller.stopListening('notificationLimit', Mojo.Event.propertyChange, this.notificationLimitChanged);
	},

	openUnknownContacts: function(event) {
		this.controller.serviceRequest('palm://com.palm.applicationManager', {"method": "launch", 
			"parameters": {"id": "com.palm.app.contacts", "params": {"launchType": "editUnknown"}}});
	},

	notificationsEnabledChanged: function(event) {
		if(event.value == true) {
			this.controller.get('notificationsEnabledRow').removeClassName("single");
			this.controller.get('notificationsEnabledRow').addClassName("first");
			this.controller.get('notificationBlinkRow').show();
			this.controller.get('notificationPrefs').show();
		}
		else {
			this.controller.get('notificationsEnabledRow').removeClassName("first");
			this.controller.get('notificationsEnabledRow').addClassName("single");
			this.controller.get('notificationBlinkRow').hide();
			this.controller.get('notificationPrefs').hide();
		}
		
		this.messagingPrefs.setNotificationsEnabled(event.value, this.serviceName)
	},

	notificationBlinkChanged: function(event) {
		this.messagingPrefs.setNotificationBlink(event.value, this.serviceName)
	},

	notificationSoundChanged: function(event) {
		if(event.value == "ringtone") {
			this.controller.get('notificationSoundRow').removeClassName("single");
			this.controller.get('notificationSoundRow').addClassName("first");
			this.controller.get('notificationRingtoneRow').show();

			var ringtone = this.messagingPrefs.getRingtone(this.serviceName);
			
			if((ringtone.name == undefined) || (ringtone.name == ""))
				this.chooseNotificationRingtone();
		}
		else {
			this.controller.get('notificationSoundRow').removeClassName("first");
			this.controller.get('notificationSoundRow').addClassName("single");
			this.controller.get('notificationRingtoneRow').hide();
		}

		this.messagingPrefs.setNotificationSound(event.value, this.serviceName)
	},

	chooseNotificationRingtone: function() {
		var ringtone = this.messagingPrefs.getRingtone(this.serviceName);
			
		if((ringtone.path == undefined) || (ringtone.path == ""))
			ringtone.path = "";

		var params = {
			actionType: "attach",
			defaultKind: 'ringtone',
			kinds: ["ringtone"],
			filePath: ringtone.path,
			actionName: $L("Done"),
			onSelect: this.handleRingtoneSelect.bind(this)
		};

		Mojo.FilePicker.pickFile(params, this.controller.stageController);
	},

	handleRingtoneSelect: function(file) {
		if((file) && (file.name)) {
			this.messagingPrefs.setRingtone({name: file.name, path: file.fullPath}, this.serviceName);

			this.controller.get('notificationRingtone').update(file.name);
		}
		else {
			this.messagingPrefs.setRingtone(undefined, this.serviceName);

			this.controller.get('notificationRingtone').update("");
		}
	},

	notificationRepeatChanged: function(event) {
		if(event.value != 0) {
			this.controller.get('notificationRepeatRow').removeClassName("single");
			this.controller.get('notificationRepeatRow').addClassName("first");
			this.controller.get('notificationLimitRow').show();
		}
		else {
			this.controller.get('notificationRepeatRow').removeClassName("first");
			this.controller.get('notificationRepeatRow').addClassName("single");
			this.controller.get('notificationLimitRow').hide();
		}

		this.messagingPrefs.setRepeatInterval(event.value, this.serviceName)
	},
	
	notificationLimitChanged: function(event) {
		this.messagingPrefs.setRepeatLimit(event.value, this.serviceName)
	}
});

