var PrefsSetupSMSAccountAssistant = Class.create({
	initialize: function(messaging) {
		this.messaging = messaging;
		
		this.messagingPrefs = messaging.messagingPrefs;
		
		this.messageForwardChanged = this.messageForwardChanged.bindAsEventListener(this);
		this.messageGreetingChanged = this.messageGreetingChanged.bindAsEventListener(this);
		this.messageSignatureChanged = this.messageSignatureChanged.bindAsEventListener(this);
		this.autoDownloadToggleChanged = this.autoDownloadToggleChanged.bindAsEventListener(this);
		this.deliveryReceiptsToggleChanged = this.deliveryReceiptsToggleChanged.bindAsEventListener(this);
	},
	
	setup: function() {
		this.controller.setInitialFocusedElement(null); 
		
		this.modelPrependForward = {value: this.messagingPrefs.getPrependForward()};
		
		this.controller.setupWidget('msgPrependForward', {}, this.modelPrependForward);
		
		this.controller.listen(this.controller.get("msgPrependForward"), Mojo.Event.propertyChange, 
			this.messageForwardChanged);
		
		this.modelMessageGreeting = {value: this.messagingPrefs.getMessageGreeting()};
		
		this.controller.setupWidget('msgGreeting', {autoFocus: false, multiline: true, 
			hintText: $L("Message greeting text...")}, this.modelMessageGreeting);
		
		this.controller.listen(this.controller.get("msgGreeting"), Mojo.Event.propertyChange, 
			this.messageGreetingChanged);
		
		this.modelMessageSignature = {value: this.messagingPrefs.getMessageSignature()};
		
		this.controller.setupWidget('msgSignature', {autoFocus: false, multiline: true, 
			hintText: $L("Message signature text...")}, this.modelMessageSignature);
		
		this.controller.listen(this.controller.get("msgSignature"), Mojo.Event.propertyChange, 
			this.messageSignatureChanged);
		
		if(this.messaging.smsRequestDeliveryReceiptAvailable) {
			this.modelDeliveryReceipts = {value: this.messagingPrefs.getUseDeliveryReceipts()};
			this.controller.setupWidget('deliveryReceiptsToggle', {}, this.modelDeliveryReceipts);
		}
		else
			this.controller.get('smsSettingsGroup').hide();
		
		this.controller.listen(this.controller.get("deliveryReceiptsToggle"), Mojo.Event.propertyChange, 
			this.deliveryReceiptsToggleChanged);
		
		if(this.messaging.supportMmsDelayedRetrievalOption) {
			this.modelAutoDownload = {value: this.messagingPrefs.getUseImmediateMmsRetrieval()};
			this.controller.setupWidget('autoDownloadToggle', {}, this.autoDownloadModel);
		}
		else
			this.controller.get('mmsSettingsGroup').hide();
		
		this.controller.listen(this.controller.get("autoDownloadToggle"), Mojo.Event.propertyChange, 
			this.autoDownloadToggleChanged);
	},
	
	cleanup: function() {
		this.controller.stopListening('msgPrependForward',Mojo.Event.propertyChange,this.messageForwardChanged);
		this.controller.stopListening('msgGreeting',Mojo.Event.propertyChange,this.messageGreetingChanged);
		this.controller.stopListening('msgSignature',Mojo.Event.propertyChange,this.messageSignatureChanged);
		this.controller.stopListening('deliveryReceiptsToggle',Mojo.Event.propertyChange,this.deliveryReceiptsToggleChanged);
		this.controller.stopListening('autoDownloadToggle',Mojo.Event.propertyChange,this.autoDownloadToggleChanged);
	},
	
	messageForwardChanged: function(event) {
		this.messagingPrefs.setPrependForward(event.value);
	},
	
	messageGreetingChanged: function(event) {
		this.messagingPrefs.setMessageGreeting(event.value);
	},
	
	messageSignatureChanged: function(event) {
		this.messagingPrefs.setMessageSignature(event.value);
	},
	
	deliveryReceiptsToggleChanged: function(event) {
		this.messagingPrefs.setUseDeliveryReceipts(event.value);
	},
	
	autoDownloadToggleChanged: function(event) {
		this.messagingPrefs.setUseImmediateMmsRetrieval(event.value);
	}
});

