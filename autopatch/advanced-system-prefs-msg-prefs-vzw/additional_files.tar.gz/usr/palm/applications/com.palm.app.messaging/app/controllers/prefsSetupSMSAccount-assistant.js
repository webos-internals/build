var PrefsSetupSMSAccountAssistant = Class.create({
	initialize: function(messaging) {
		this.messaging = messaging;
		
		this.messagingPrefs = messaging.messagingPrefs;

		this.autoDownloadToggleChanged = this.autoDownloadToggleChanged.bindAsEventListener(this);
		this.deliveryReceiptsToggleChanged = this.deliveryReceiptsToggleChanged.bindAsEventListener(this);
		this.messageGreetingChanged = this.messageGreetingChanged.bindAsEventListener(this);
		this.messageSignatureChanged = this.messageSignatureChanged.bindAsEventListener(this);
	},
	
	setup: function() {
		this.controller.setInitialFocusedElement(null); 

		if(this.messaging.supportMmsDelayedRetrievalOption) {
			this.modelAutoDownload = {value: this.messagingPrefs.getUseImmediateMmsRetrieval()};
			this.controller.setupWidget('autoDownloadToggle', {}, this.autoDownloadModel);   
		}
		else
			this.controller.get('autoDownloadRow').hide();

		this.controller.listen(this.controller.get("autoDownloadToggle"), Mojo.Event.propertyChange, 
			this.autoDownloadToggleChanged);

		if(this.messaging.mmsRequestDeliveryReceiptAvailable) {
			this.modelDeliveryReceipts = {value: this.messagingPrefs.getUseDeliveryReceipts()};
			this.controller.setupWidget('deliveryReceiptsToggle', {}, this.modelDeliveryReceipts);   
		}
		else
			this.controller.get('deliveryReceiptsRow').hide();

		this.controller.listen(this.controller.get("deliveryReceiptsToggle"), Mojo.Event.propertyChange, 
			this.deliveryReceiptsToggleChanged);

		if((!this.messaging.supportMmsDelayedRetrievalOption) && 
			(!this.messaging.mmsRequestDeliveryReceiptAvailable))
		{
			this.controller.get('mmsSettingsGroup').hide();
		}
		else if((this.messaging.supportMmsDelayedRetrievalOption) && 
			(!this.messaging.mmsRequestDeliveryReceiptAvailable))
		{
	      this.controller.get('autoDownloadRow').removeClass("first");
	      this.controller.get('autoDownloadRow').addClass("single");
		}
		else if((!this.messaging.supportMmsDelayedRetrievalOption) && 
			(this.messaging.mmsRequestDeliveryReceiptAvailable))
		{
	      this.controller.get('deliveryReceiptsRow').removeClass("first");
	      this.controller.get('deliveryReceiptsRow').addClass("single");
		}

		this.modelMessageGreeting = {value: this.messagingPrefs.getMessageGreeting()};

		this.controller.setupWidget('msgGreeting', {autoFocus: false, multiline: true, 
			hintText: $L("Message greeting text...")}, this.modelMessageGreeting);

		this.controller.listen(this.controller.get("msgGreeting"), Mojo.Event.propertyChange, 
			this.messageGreetingChanged);

		this.modelMessageSignature = {value: this.messagingPrefs.getMessageSignature()};

		this.controller.setupWidget('msgSignature', {autoFocus: false, multiline: true, 
			hintText: $L("Message signature text...")}, this.modelMessageSignature);

		this.controller.listen(this.controller.get("msgSignature"), Mojo.Event.propertyChange, 
			this.messageSignatureChanged);
	},

	cleanup: function() {
		this.controller.stopListening('autoDownloadToggle',Mojo.Event.propertyChange,this.autoDownloadToggleChanged);
		this.controller.stopListening('deliveryReceiptsToggle',Mojo.Event.propertyChange,this.deliveryReceiptsToggleChanged);
		this.controller.stopListening('msgGreeting',Mojo.Event.propertyChange,this.messageGreetingChanged);
		this.controller.stopListening('msgSignature',Mojo.Event.propertyChange,this.messageSignatureChanged);
	},

	autoDownloadToggleChanged: function(event) {
		this.messagingPrefs.setUseImmediateMmsRetrieval(event.value);
	},
	
	deliveryReceiptsToggleChanged: function(event) {
		this.messagingPrefs.setUseDeliveryReceipts(event.value);
	},

	messageGreetingChanged: function(event) {
		this.messagingPrefs.setMessageGreeting(event.value);
	},

	messageSignatureChanged: function(event) {
		this.messagingPrefs.setMessageSignature(event.value);
	}	
});

