var LedControlAssistant = function(){
}
  
LedControlAssistant.prototype.run = function(future) {  
	var ledState = "disabled";

	var fs = IMPORTS.require('fs');

	if(this.controller.args.state == "enabled") {
		ledState = "enabled";

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/avin', '1', function(err) {
			if(err) throw err;
		});

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/torch_current', '100mA', function(err) {
			if(err) throw err;
		});

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/mode', 'torch', function(err) {
			if(err) throw err;
		});
	}
	else if(this.controller.args.state == "disabled") {
		ledState = "disabled";

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/mode', 'shutdown', function(err) {
			if(err) throw err;
		});

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/torch_current', '0mA', function(err) {
			if(err) throw err;
		});

		fs.writeFile('/sys/class/i2c-adapter/i2c-2/2-0033/avin', '0', function(err) {
			if(err) throw err;
		});
	}
	else {
		var fd = fs.openSync("/sys/class/i2c-adapter/i2c-2/2-0033/avin",'r',0666);
		
		var data = fs.readSync(fd, 2, null); 

		if(data[0].substring(0,1) == "1")
			var ledState = "enabled";
		
		fs.close(fd);
	}
		
   future.result = { state: ledState };
}

