Date.prototype.getISO8601Week = function() {
	var d = new Date(this);

	d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7 + 3);

	var e = d.valueOf();

	d.setUTCMonth(0, 4);

	var w = Math.round((e - d.valueOf()) / 604800000) + 1;

	if (w <= 9) { w = "0" + w; }

	return w;
}

