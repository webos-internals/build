var IMsgAlert = PropertyBase.create({
	data: [
		{
			dbFieldName: "alert",
			defaultValue: "",
			setterName: "setAlert",
			getterName: "getAlert"
		}
	]
});
