var PrefsAssistant = Class.create({
	initialize: function(phonePrefs) {
		this.phonePrefs = phonePrefs;
	},
	
	setup: function() {
		this.controller.document.body.className = "prefs";

		this.controller.setInitialFocusedElement(null); 

		if(this.phonePrefs.defaultView == undefined)
			this.phonePrefs.defaultView = "dialpad";

		if(this.phonePrefs.onCallView == undefined)
			this.phonePrefs.onCallView = "contact";

		if(this.phonePrefs.closeAfterCall == undefined)
			this.phonePrefs.closeAfterCall = false;

		if(this.phonePrefs.sliderOpenAction == undefined)
			this.phonePrefs.sliderOpenAction = "answercall";

		if(this.phonePrefs.sliderCloseAction == undefined)
			this.phonePrefs.sliderCloseAction = "hangupcall";

		if(this.phonePrefs.touchstoneAction == undefined)
			this.phonePrefs.touchstoneAction = "answercall";

		if(this.phonePrefs.rejectedAction == undefined)
			this.phonePrefs.rejectedAction = "nothing";

		if(this.phonePrefs.rejectedTemplate == undefined)
			this.phonePrefs.rejectedTemplate = "";

		if(this.phonePrefs.speakerphoneMode == undefined)
			this.phonePrefs.speakerphoneMode = "manual";

		if(this.phonePrefs.notificationBlink == undefined)
			this.phonePrefs.notificationBlink = false;

		if(this.phonePrefs.notificationRepeat == undefined)
			this.phonePrefs.notificationRepeat = 0;

		if(this.phonePrefs.notificationTimes == undefined)
			this.phonePrefs.notificationTimes = 3;

		if(this.phonePrefs.rejectedAction != "autoreply")
			this.controller.get("RejectedTextRow").hide();
	
		this.modelMatchContacts = { value: true, disabled: false };

		this.controller.setupWidget('MatchContacts', 
			{falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelMatchContacts);

		this.controller.listen(this.controller.get("MatchContacts"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesDefaultView = [
			{label: $L("Dialpad"), value: "dialpad"},
			{label: $L("Call log"), value: "calllog"} ];

		this.modelDefaultView = {value: this.phonePrefs.defaultView, disabled: false};

		this.controller.setupWidget("DefaultView", {
			label: $L("Default View"),
			labelPlacement: "left", 							
			choices: this.choicesDefaultView},
			this.modelDefaultView);

		this.controller.listen(this.controller.get("DefaultView"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesOnCallView = [
			{label: $L("Contact"), value: "contact"},
			{label: $L("Dialpad"), value: "dialpad"} ];

		this.modelOnCallView = {value: this.phonePrefs.onCallView, disabled: false};

		this.controller.setupWidget("OnCallView", {
			label: $L("On Call View"),
			labelPlacement: "left", 							
			choices: this.choicesOnCallView},
			this.modelOnCallView);

		this.controller.listen(this.controller.get("OnCallView"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.modelCloseAfter = { value: this.phonePrefs.closeAfterCall, disabled: false };

		this.controller.setupWidget('CloseAfter', 
			{falseLabel: $L("No"), trueLabel: $L("Yes")},
		   this.modelCloseAfter);

		this.controller.listen(this.controller.get("CloseAfter"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesSliderOpened = [
			{label: $L("Do Nothing"), value: "nothing"},
			{label: $L("Answer Call"), value: "answercall"},
			{label: $L("Speakerphone"), value: "speakerphone"} ];

		this.modelSliderOpened = {value: this.phonePrefs.sliderOpenAction, disabled: false};

		this.controller.setupWidget("SliderOpened", {
			label: $L("Slider Opened"),
			labelPlacement: "left", 							
			choices: this.choicesSliderOpened},
			this.modelSliderOpened);

		this.controller.listen(this.controller.get("SliderOpened"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesSliderClosed = [
			{label: $L("Do Nothing"), value: "nothing"},
			{label: $L("Hangup Call"), value: "hangupcall"} ];

		this.modelSliderClosed = {value: this.phonePrefs.sliderCloseAction, disabled: false};

		this.controller.setupWidget("SliderClosed", {
			label: $L("Slider Closed"),
			labelPlacement: "left", 							
			choices: this.choicesSliderClosed},
			this.modelSliderClosed);

		this.controller.listen(this.controller.get("SliderClosed"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesTouchstoneRemove = [
			{label: $L("Do Nothing"), value: "nothing"},
			{label: $L("Answer Call"), value: "answercall"} ];

		this.modelTouchstoneRemove = {value: this.phonePrefs.touchstoneAction, disabled: false};

		this.controller.setupWidget("TSAutoAnswer", {
			label: $L("On TS Removal"),
			labelPlacement: "left", 							
			choices: this.choicesTouchstoneRemove},
			this.modelTouchstoneRemove);

		this.controller.listen(this.controller.get("TSAutoAnswer"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
			
		this.choicesRejectedCall = [
			{label: $L("Do Nothing"), value: "nothing"},
			{label: $L("Auto Reply"), value: "autoreply"} ];

		this.modelRejectedCall = {value: this.phonePrefs.rejectedAction, disabled: false};

		this.controller.setupWidget("RejectedCall", {
			label: $L("On Call Reject"),
			labelPlacement: "left", 							
			choices: this.choicesRejectedCall},
			this.modelRejectedCall);

		this.controller.listen(this.controller.get("RejectedCall"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
		
		this.modelRejectedText = {value: this.phonePrefs.rejectedTemplate, disabled: false};

		this.controller.setupWidget("RejectedText", {'hintText': $L("Template text for auto reply..."), 
		'multiline': true, 'enterSubmits': false, 'autoFocus': false}, this.modelRejectedText); 

		this.controller.listen(this.controller.get("RejectedText"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesSpeakerActivation = [
			{label: $L("Only Manually"), value: "manual"},
			{label: $L("Using Proximity"), value: "proximity"} ];

		this.modelSpeakerActivation = {value: this.phonePrefs.speakerphoneMode, disabled: false};

		this.controller.setupWidget("SpeakerActivation", {
			label: $L("Speakerphone"),
			labelPlacement: "left", 							
			choices: this.choicesSpeakerActivation},
			this.modelSpeakerActivation);

		this.controller.listen(this.controller.get("SpeakerActivation"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
			
		this.choicesNotificationRepeat = [
			{label: $L("Disabled"), value: 0},
			{label: $L("Every 2 minutes"), value: 120},
			{label: $L("Every 5 minutes"), value: 300},
			{label: $L("Every 15 minutes"), value: 900},
			{label: $L("Every 30 minutes"), value: 1800},
			{label: $L("Every 60 minutes"), value: 3600} ];

		this.modelNotificationBlink = { value: this.phonePrefs.notificationBlink, disabled: false };
		
		this.controller.setupWidget('NotificationBlink', 
			{falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelNotificationBlink);

		this.controller.listen(this.controller.get("NotificationBlink"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
			
		this.modelNotificationRepeat = {value: this.phonePrefs.notificationRepeat, disabled: false};

		this.controller.setupWidget("NotificationRepeat", {
			label: $L("Repeat"),
			labelPlacement: "left", 							
			choices: this.choicesNotificationRepeat},
			this.modelNotificationRepeat);

		this.controller.listen(this.controller.get("NotificationRepeat"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesNotificationTimes = [
			{label: $L("Infinite"), value: 999},
			{label: $L("3 times"), value: 3},
			{label: $L("5 times"), value: 5},
			{label: $L("10 times"), value: 10},
			{label: $L("15 times"), value: 15},
			{label: $L("30 times"), value: 30} ];

		this.modelNotificationTimes = {value: this.phonePrefs.notificationTimes, disabled: false};

		this.controller.setupWidget("NotificationTimes", {
			label: $L("Repeat Times"),
			labelPlacement: "left", 							
			choices: this.choicesNotificationTimes},
			this.modelNotificationTimes);

		this.controller.listen(this.controller.get("NotificationTimes"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		if(this.modelNotificationRepeat.value == 0) {
			this.controller.get("NotificationRepeatRow").addClassName("last");
			this.controller.get("NotificationTimesRow").hide();
		}

		this.getPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'getPreferences', parameters: {'keys': ["showcontactmatch"]},
			onSuccess: function(response) {
				if(response.showcontactmatch != undefined) {
					this.modelMatchContacts.value = response.showcontactmatch;
		
					this.controller.modelChanged(this.modelMatchContacts, this);
				}	
			}.bind(this) });
	},

	savePreferences: function(event) {
		if(this.modelNotificationRepeat.value == 0) {
			this.controller.get("NotificationRepeatRow").addClassName("last");
			this.controller.get("NotificationTimesRow").hide();
		}
		else {
			this.controller.get("NotificationRepeatRow").removeClassName("last");
			this.controller.get("NotificationTimesRow").show();
		}

		if(this.modelRejectedCall.value == "autoreply")
			this.controller.get("RejectedTextRow").show();
		else
			this.controller.get("RejectedTextRow").hide();

		this.phonePrefs.defaultView = this.modelDefaultView.value;
		this.phonePrefs.onCallView = this.modelOnCallView.value;
		this.phonePrefs.closeAfterCall = this.modelCloseAfter.value;
		this.phonePrefs.sliderOpenAction = this.modelSliderOpened.value;
		this.phonePrefs.sliderCloseAction = this.modelSliderClosed.value;
		this.phonePrefs.touchstoneAction = this.modelTouchstoneRemove.value;
		this.phonePrefs.rejectedAction = this.modelRejectedCall.value;
		this.phonePrefs.rejectedTemplate = this.modelRejectedText.value;
		this.phonePrefs.speakerphoneMode = this.modelSpeakerActivation.value;
		this.phonePrefs.notificationBlink = this.modelNotificationBlink.value;
		this.phonePrefs.notificationRepeat = parseInt(this.modelNotificationRepeat.value);
		this.phonePrefs.notificationTimes = parseInt(this.modelNotificationTimes.value);
		
		if(this.setPreferencesRequest)
			this.setPreferencesRequest.cancel();
		
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {phonePrefs: this.phonePrefs, BlinkNotifications: true, 
				showcontactmatch: this.modelMatchContacts.value} });
	},
	
	cleanup: function() {
		this.controller.document.body.className = "palm-default";
	}
});

