var PrefsSetupSMSAccountAssistant = Class.create({
	initialize: function(messagingPrefs, msgPrefs) {
		this.messagingPrefs = messagingPrefs;
		this.msgPrefs = msgPrefs;

		this.notificationToggleChanged = this.notificationToggleChanged.bindAsEventListener(this);
		this.notificationSoundToggleChanged = this.notificationSoundToggleChanged.bindAsEventListener(this);
		this.chooseNotificationRingtone = this.chooseNotificationRingtone.bindAsEventListener(this);
		this.autoDownloadToggleChanged = this.autoDownloadToggleChanged.bindAsEventListener(this);
	},
	
	setup: function() {
		this.controller.setInitialFocusedElement(null); 
	
		if(this.msgPrefs["sms"] == undefined)
			this.msgPrefs["sms"] = {};
		
		if(this.msgPrefs["sms"].blinkNotify == undefined)
			this.msgPrefs["sms"].blinkNotify = false;

		if(this.msgPrefs["sms"].vibrationLength == undefined)
			this.msgPrefs["sms"].vibrationLength = 0;

		if(this.msgPrefs["sms"].notificationRepeat == undefined)
			this.msgPrefs["sms"].notificationRepeat = 0;

		if(this.msgPrefs["sms"].notificationTimes == undefined)
			this.msgPrefs["sms"].notificationTimes =  3;

		if(this.msgPrefs["sms"].messageGreeting == undefined)
			this.msgPrefs["sms"].messageGreeting = "";

		if(this.msgPrefs["sms"].messageSignature == undefined)
			this.msgPrefs["sms"].messageSignature = "";
	
		this.cmdMenuModel = {
			visible: true,
			items: [{},{toggleCmd: "accountinfo", items: [{label: "Account Info", command: "accountinfo", width: 160}, {label: "Preferences", command: "preferences", width: 160}]},{}]
		};
		
		this.controller.setupWidget(Mojo.Menu.commandMenu, undefined, this.cmdMenuModel);
	
		this.prefsSmsMmsSetup();
	
      if(this.messagingPrefs.enableNotification == undefined)
        this.messagingPrefs.enableNotification = false;      
      if(this.messagingPrefs.enableNotificationSound == undefined)
        this.messagingPrefs.enableNotificationSound = 0;
      
      if(!this.messagingPrefs.enableNotification)
        this.controller.get('notificationprefs').hide();
      
      var notificationAttributes = {
        modelProperty: "value"
      };
      this.notificationModel = {
        value: this.messagingPrefs.enableNotification
      };
      this.controller.setupWidget('notificationToggle', notificationAttributes, this.notificationModel);   
      
      var autoDownloadAttributes = {
        modelProperty: "value"
      };
      this.autoDownloadModel = {
        value: this.messagingPrefs.useImmediateMmsRetrieval
      };
	  if (this.messagingPrefs.supportDelayedRetrievalOption === false){
	  	this.controller.get('autoDownloadToggleRow').hide();
		this.controller.get('soundtogglerow').addClassName("last");
	  }
      this.controller.setupWidget('autoDownloadToggle', autoDownloadAttributes, this.autoDownloadModel);   
      
      this.notificationSoundModel = {
        value: this.messagingPrefs.enableNotificationSound
      };
	           
      var soundSelections = {
      	modelProperty: 'value',
      	label: $L("Alert"),
      	choices: [
      		{label: $L('Vibrate'), value: 3},
      		{label: $L('System Sound'), value: 1},
      		{label: $L('Ringtone'), value: 2},
      		{label: $L('Mute'), value: 0}
      	]
      };
	  this.controller.setupWidget('notificationSoundSelector', soundSelections, this.notificationSoundModel);
      
	  this.controller.get('currentringtone').update(this.messagingPrefs.notificationRingtoneName);

      this.controller.listen('currentringtonerow',Mojo.Event.tap, this.chooseNotificationRingtone);
  
      this.controller.listen('notificationToggle',Mojo.Event.propertyChange,this.notificationToggleChanged);
      this.controller.listen('notificationSoundSelector',Mojo.Event.propertyChange,this.notificationSoundToggleChanged);
	  if (this.messagingPrefs.enableNotificationSound != 2)
	  	this.controller.get('currentringtonerow').hide();
	  	
	  if (this.messagingPrefs.enableNotificationSound == 0) {
	  	this.controller.get('soundselectrow').removeClassName("first");
	  	this.controller.get('soundselectrow').addClassName("single");
		this.controller.get('vibrationlengthrow').hide();
		this.controller.get('NotificationRepeatRow').hide();
		this.controller.get('NotificationTimesRow').hide();
	  }
      this.controller.listen('autoDownloadToggle',Mojo.Event.propertyChange,this.autoDownloadToggleChanged);

		this.choicesVibrationLength = [
			{label: $L("Disabled"), value: 0},
			{label: $L("Short (0.5s)"), value: 500},
			{label: $L("Medium (1.0s)"), value: 1000},
			{label: $L("Long (1.5s)"), value: 1500} ];

		this.modelVibrationLength = {value: this.msgPrefs["sms"].vibrationLength, disabled: false};

		this.controller.setupWidget("vibrationlength", {
			label: $L("Vibration"),
			labelPlacement: "right", 							
			choices: this.choicesVibrationLength},
			this.modelVibrationLength);

		this.controller.listen(this.controller.get("vibrationlength"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesNotificationRepeat = [
			{label: $L("Disabled"), value: 0},
			{label: $L("Every 2 minutes"), value: 120},
			{label: $L("Every 5 minutes"), value: 300},
			{label: $L("Every 15 minutes"), value: 900},
			{label: $L("Every 30 minutes"), value: 1800},
			{label: $L("Every 60 minutes"), value: 3600} ];

		this.modelNotificationRepeat = {value: this.msgPrefs["sms"].notificationRepeat, disabled: false};

		this.controller.setupWidget("NotificationRepeat", {
			label: $L("Repeat"),
			labelPlacement: "right", 							
			choices: this.choicesNotificationRepeat},
			this.modelNotificationRepeat);

		this.controller.listen(this.controller.get("NotificationRepeat"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.choicesNotificationTimes = [
			{label: $L("Repeat infinitely"), value: 999},
			{label: $L("Repeat 3 times"), value: 3},
			{label: $L("Repeat 5 times"), value: 5},
			{label: $L("Repeat 10 times"), value: 10},
			{label: $L("Repeat 15 times"), value: 15},
			{label: $L("Repeat 30 times"), value: 30} ];

		this.modelNotificationTimes = {value: this.msgPrefs["sms"].notificationTimes, disabled: false};

		this.controller.setupWidget("NotificationTimes", {
			label: $L("Repeat Times"),
			labelPlacement: "right", 							
			choices: this.choicesNotificationTimes},
			this.modelNotificationTimes);

		this.controller.listen(this.controller.get("NotificationTimes"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.modelNotificationBlink = { value: this.msgPrefs["sms"].blinkNotify, disabled: false };

		this.controller.setupWidget('NotificationBlink', 
			{falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelNotificationBlink);

		this.controller.listen(this.controller.get("NotificationBlink"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
			
		if(this.msgPrefs["sms"].notificationRepeat == false) {
		  	this.controller.get('NotificationRepeatRow').addClassName("last");
			this.controller.get('NotificationTimesRow').hide();
		}
	},

	savePreferences: function(event) {
		if(this.modelNotificationRepeat.value == false) {
		  	this.controller.get('NotificationRepeatRow').addClassName("last");
			this.controller.get('NotificationTimesRow').hide();
		}
		else {
		  	this.controller.get('NotificationRepeatRow').removeClassName("last");
			this.controller.get('NotificationTimesRow').show();
		}
	
		this.msgPrefs["sms"].messageGreeting = this.greetingModel.value;
		this.msgPrefs["sms"].messageSignature = this.signatureModel.value;
	
		this.msgPrefs["sms"].blinkNotify = this.modelNotificationBlink.value;
		this.msgPrefs["sms"].vibrationLength = parseInt(this.modelVibrationLength.value);
		this.msgPrefs["sms"].notificationRepeat = parseInt(this.modelNotificationRepeat.value);
		this.msgPrefs["sms"].notificationTimes = parseInt(this.modelNotificationTimes.value);				

		this.setPreferencesRequest = this.controller.serviceRequest('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {msgPrefs: this.msgPrefs, BlinkNotifications: true} });
	},

	handleCommand: function(event) {
		if (event.type == Mojo.Event.command) {
			switch (event.command) {
				case 'accountinfo':
					this.controller.getSceneScroller().mojo.revealTop();
					this.cmdMenuModel.items[1].toggleCmd = "accountinfo";
					this.controller.modelChanged(this.cmdMenuModel, this);
					this.controller.get("preferences").hide();
					this.controller.get("accountinfo").show();
					break;
				case 'preferences':
					this.controller.getSceneScroller().mojo.revealTop();
					this.cmdMenuModel.items[1].toggleCmd = "preferences";
					this.controller.modelChanged(this.cmdMenuModel, this);
					this.controller.get("accountinfo").hide();
					this.controller.get("preferences").show();
					break;
			}
		}
	},

	cleanup: function() {
		this.controller.stopListening('notificationToggle',Mojo.Event.propertyChange,this.notificationToggleChanged);
		this.controller.stopListening('notificationSoundSelector',Mojo.Event.propertyChange,this.notificationSoundToggleChanged);		
		this.controller.stopListening('autoDownloadToggle',Mojo.Event.propertyChange,this.autoDownloadToggleChanged);
	},

    prefsSmsMmsSetup: function() {
		this.greetingModel = {value: this.msgPrefs["sms"].messageGreeting};

		this.controller.setupWidget('msgGreeting', {autoFocus: false, multiline: true, hintText: "Message greeting text..."}, this.greetingModel);

		this.controller.listen(this.controller.get("msgGreeting"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));

		this.signatureModel = {value: this.msgPrefs["sms"].messageSignature};

		this.controller.setupWidget('msgSignature', {autoFocus: false, multiline: true, hintText: "Message signature text..."}, this.signatureModel);

		this.controller.listen(this.controller.get("msgSignature"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
			    
      /************************
      * Setup widgets
      ************************/
      var smscAttributes = {
        textFieldName: "smscAddressText",
        hintText: '',
        modelProperty: 'original',
        multiline: false,
        focus: false
      };
      this.smscModel = {
        original: '',
        disabled: true
      };
      this.controller.setupWidget('smscAddress', smscAttributes, this.smscModel);  
      
      var emailGatewayAttributes = {
        textFieldName: "emailGatewayText",
        hintText: '',
        modelProperty: 'original',
        multiline: false,
        focus: false
      };
      this.emailGatewayModel = {
        original: '',
        disabled: true
      };
      this.controller.setupWidget('emailGateway', emailGatewayAttributes, this.emailGatewayModel);              
      
      var mmscAttributes = {
        textFieldName: "mmscAddressText",
        hintText: '',
        modelProperty: 'original',
        multiline: false,
        focus: false
      };
      this.mmscModel = {
        original: '',
        disabled: true
      };
      this.controller.setupWidget('mmscAddress', mmscAttributes, this.mmscModel);  
      
      var mmscProxyAttributes = {
        textFieldName: "mmscProxyText",
        hintText: '',
        modelProperty: 'original',
        multiline: false,
        focus: false
      };
      this.mmscProxyModel = {
        original: '',
        disabled: true
      };
      this.controller.setupWidget('mmscProxy', mmscProxyAttributes, this.mmscProxyModel);          
/*
      var mmsSmsUseSettingsAttributes = {
        modelProperty: "value"
      };
      this.mmsSmsUseSettingsModel = {
        value: false
      };
      this.controller.setupWidget('useSettings', mmsSmsUseSettingsAttributes, this.mmsSmsUseSettingsModel);        
*/        
      /*********************************************
      * Methods for rendering existing pref values
      *********************************************/        
      this.renderEditSMSCAddress = function(response) {
        this.smscModel.original = response.smscAddr;
        this.controller.modelChanged(this.smscModel,this);
        this.emailGatewayModel.original = response.emailGateway;
        this.controller.modelChanged(this.emailGatewayModel,this);        
      };            
          
	  this.renderEditMMSSettings = function(response){
	  	this.mmscModel.original = response.mmsc;
	  	this.controller.modelChanged(this.mmscModel, this);
	  	this.mmscProxyModel.original = response.proxy;
	  	this.controller.modelChanged(this.mmscProxyModel, this);
	  	
/*	  if (response.useMmscProxyPrefs == true) {
	  		this.mmsSmsUseSettingsModel.value = true;
	  		this.controller.modelChanged(this.mmsSmsUseSettingsModel, this);
	  	} else {
	  		this.mmsSmsUseSettingsModel.value = false;
	  		this.controller.modelChanged(this.mmsSmsUseSettingsModel, this);
	  	}*/
	  };       
      
      // Saving the pref data in a batch like this because that is how the service
      // is currently set up.  Since these SMS/MMS prefs are for GCF this is fine.      
      this.saveSMSPrefs = function(e) {
        var smscAddress = this.controller.get('smscAddress').querySelector('[name=smscAddressText]').value;
        var emailGateway = this.controller.get('emailGateway').querySelector('[name=emailGatewayText]').value;
        var mmscAddress = this.controller.get('mmscAddress').querySelector('[name=mmscAddressText]').value;
        var mmscProxy = this.controller.get('mmscProxy').querySelector('[name=mmscProxyText]').value;
        var useMmsSettings = this.mmsSmsUseSettingsModel.value
    		this.requests.push(MessagingMojoService.setSMSCAddressAndEmailGateway(smscAddress, emailGateway,this.controller));
    		this.requests.push(MessagingMojoService.setMMSSettings(mmscAddress, mmscProxy, useMmsSettings, this.controller));
    		this.controller.stageController.popScene();
    	}.bind(this);        
      
      //this.controller.listen('savePrefs',Mojo.Event.tap,this.saveSMSPrefs);        
      
      // Retrieve SMS & MMS preferences to populate pref text fields
      MessagingMojoService.getSMSCAddressAndEmailGateway(this.renderEditSMSCAddress.bind(this), this.controller);
      MessagingMojoService.getMMSSettings(this.renderEditMMSSettings.bind(this), this.controller); 
    },
    
	notificationToggleChanged: function(event) {
 		// if disabling notifications, hide the sound toggle       
        if(event.value == false) {
          this.controller.get('notificationprefs').hide();
		  }
        else {
          this.controller.get('notificationprefs').show();
         }
          
        // save the pref
		var params = {
			isEnabledNotification: event.value
		};		
        MessagingMojoService.setNotificationPreferences(this.controller,params);		
	},
	
	autoDownloadToggleChanged: function(event) {
        MessagingMojoService.setNotificationPreferences(this.controller, { isImmediateMmsRetrieval: event.value });		
	},
	
	notificationSoundToggleChanged: function(event) {
        // save the pref 
		Mojo.Log.info("notificationSoundToggleChanged %j", event);
		if (event.value == "2") {
		  	this.controller.get('currentringtonerow').show();
		  	this.controller.get('vibrationlengthrow').show();		  	
		  	this.controller.get('NotificationRepeatRow').show();
		  	this.controller.get('NotificationTimesRow').show();
			// If no ringtone is set, then display the picker
			var ringtoneName = this.messagingPrefs.notificationRingtoneName;
			Mojo.Log.info("ringtoneName",ringtoneName);
			if (ringtoneName == null || ringtoneName == "") {
				this.chooseNotificationRingtone();
			}
		} else {
		  	this.controller.get('currentringtonerow').hide();
		  	if (event.value == "0") {
			  	this.controller.get('soundselectrow').addClassName("single");
			  	this.controller.get('soundselectrow').removeClassName("first");
			  	this.controller.get('vibrationlengthrow').hide();		  	
			  	this.controller.get('NotificationRepeatRow').hide();
			  	this.controller.get('NotificationTimesRow').hide();
			}
			else {
			  	this.controller.get('soundselectrow').removeClassName("single");
			  	this.controller.get('soundselectrow').addClassName("first");
			  	this.controller.get('vibrationlengthrow').show();
  			  	this.controller.get('NotificationRepeatRow').show();
			  	this.controller.get('NotificationTimesRow').show();
			}
		}

		var params = {
			isEnabledNotificationSound: event.value
		};		
        MessagingMojoService.setNotificationPreferences(this.controller,params);    		
	},
    
	chooseNotificationRingtone: function() {
    	var params = {
			actionType: "attach",
            defaultKind: 'ringtone',
			kinds: ["ringtone"],
			filePath: this.messagingPrefs.notificationRingtonePath,
			actionName: $L("Done"),
	        onSelect: this.handleRingtoneSelect.bind(this)
	    };
	    Mojo.FilePicker.pickFile(params,this.controller.stageController);
		//this.handleRingtoneSelect.bind(this, {"fullPath": "/media/internal/ringtones/Discreet.mp3", "name": "Discreet"}).delay(1);
	},

	handleRingtoneSelect: function(file) {
		Mojo.Log.info("handleRingtoneSelect %j", file);
		var params = {
			ringtonePath: file.fullPath,
			ringtoneName: file.name
		};
		MessagingMojoService.setNotificationPreferences(this.controller, params);
		this.controller.get('currentringtone').update(file.name);
	}
});

