var ContactprefsAssistant = Class.create({
	initialize: function(person) {
		if(person)
			this.person = person;
		else {
			this.contactPrefs = {
				blocked: {},
				unknown: {}
			};
			
			this.person = this.contactPrefs.unknown;
		}
	},
	
	setup: function() {
		if(this.contactPrefs)
			this.controller.get("ContactName").update("Unknown Contacts");
		else
			this.controller.get("ContactName").update(this.person.firstName + " " + this.person.lastName);

		if(this.contactPrefs)
			this.controller.get("UnknownContactsGroup").show();
		else
			this.controller.get("UnknownSettingsGroup").show();
		
		if((this.contactPrefs) && (this.contactPrefs.unknown != undefined))
			this.modelUnknownContacts = {value: true, disabled: false};
		else
			this.modelUnknownContacts = {value: false, disabled: false};

		this.controller.setupWidget('UnknownContacts', 
			{falseLabel: $L("No"), trueLabel: $L("Yes")},
		   this.modelUnknownContacts);

		this.controller.listen(this.controller.get("UnknownContacts"), Mojo.Event.propertyChange, 
			this.saveContactPreferences.bind(this));

		if((this.contactPrefs) && (this.contactPrefs.blocked != undefined))
			this.modelBlockedContacts = {value: true, disabled: false};
		else
			this.modelBlockedContacts = {value: false, disabled: false};

		this.controller.setupWidget('BlockedContacts', 
			{falseLabel: $L("No"), trueLabel: $L("Yes")},
		   this.modelBlockedContacts);

		this.controller.listen(this.controller.get("BlockedContacts"), Mojo.Event.propertyChange, 
			this.saveContactPreferences.bind(this));
	
		this.choicesCallAction = [
			{label: $L("Do Nothing"), value: "nothing"},
			{label: $L("Auto Hang Up"), value: "hangup"},
			{label: $L("Direct to Voicemail"), value: "direct2vm"} ];

		if((this.person.ringtoneLoc != undefined) && 
			((this.person.ringtoneLoc == "hangup") ||
			(this.person.ringtoneLoc == "direct2vm")))
		{
			this.modelCallAction = {value: this.person.ringtoneLoc, disabled: false};
		}
		else
			this.modelCallAction = {value: "nothing", disabled: false};
	
		this.controller.setupWidget("CallAction", {
			label: $L("Action"),
			labelPlacement: "left", 							
			choices: this.choicesCallAction},
			this.modelCallAction);

		this.controller.listen(this.controller.get("CallAction"), Mojo.Event.propertyChange, 
			this.setCallAction.bind(this));

		this.choicesRingtone = [
			{label: $L("Set Ringtone"), value: "select"},
			{label: $L("Use Default"), value: "default"} ];

		if((this.person.ringtoneLoc == undefined) || (this.person.ringtoneLoc == ""))
			this.modelRingtone = {value: "default", disabled: false};
		else
			this.modelRingtone = {value: this.person.ringtoneName, disabled: false};

		this.controller.setupWidget("Ringtone", {
			label: $L("Ringtone"),
			labelPlacement: "left", 							
			choices: this.choicesRingtone},
			this.modelRingtone);

		this.controller.listen(this.controller.get("Ringtone"), Mojo.Event.propertyChange, 
			this.selectRingtone.bind(this));

		this.choicesMsgtone = [
			{label: $L("Set Ringtone"), value: "select"},
			{label: $L("Use Default"), value: "default"} ];

		if((this.person.messagingRingtoneLoc == undefined) || (this.person.messagingRingtoneLoc == ""))
			this.modelMsgtone = {value: "default", disabled: false};
		else
			this.modelMsgtone = {value: this.person.messagingRingtoneName, disabled: false};

		this.controller.setupWidget("Msgtone", {
			label: $L("Ringtone"),
			labelPlacement: "left", 							
			choices: this.choicesMsgtone},
			this.modelMsgtone);

		this.controller.listen(this.controller.get("Msgtone"), Mojo.Event.propertyChange, 
			this.selectMsgtone.bind(this));

		if(this.modelCallAction.value != "nothing") {
			this.controller.get("CallActionRow").addClassName("single");
			this.controller.get("CallActionRow").removeClassName("first");			
			this.controller.get("RingtoneRow").hide();
		}
		
		if(this.contactPrefs)
			this.loadContactPreferences();
	},

	loadContactPreferences: function() {
		this.getPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'getPreferences', parameters: {keys: ["contactPrefs"], subscribe: false},
			onSuccess: function(response) {
				if((response) && (response.contactPrefs))
					this.contactPrefs = response.contactPrefs;
				
				if(this.contactPrefs.blocked != undefined) {
					this.controller.get("UnknownSettingsGroup").show();

					this.person = this.contactPrefs.blocked;
				}
				else {
					this.modelBlockedContacts.value = false;
					this.controller.modelChanged(this.modelBlockedContacts, this);
				}
								
				if(this.contactPrefs.unknown != undefined) {
					this.controller.get("UnknownSettingsGroup").show();

					this.person = this.contactPrefs.unknown;
				}
				else {
					this.modelUnknownContacts.value = false;
					this.controller.modelChanged(this.modelUnknownContacts, this);
				}

				if((this.person.ringtoneLoc != undefined) && 
					((this.person.ringtoneLoc == "hangup") ||
					(this.person.ringtoneLoc == "direct2vm")))
				{
					this.modelCallAction.value = this.person.ringtoneLoc;
					
					this.controller.modelChanged(this.modelCallAction, this);
					
					this.controller.get("CallActionRow").addClassName("single");
					this.controller.get("CallActionRow").removeClassName("first");			
					this.controller.get("RingtoneRow").hide();
				}
				else if((this.person.ringtoneLoc != undefined) && (this.person.ringtoneLoc != "")) {
					this.modelRingtone.value = this.person.ringtoneName;

					this.controller.modelChanged(this.modelRingtone, this);
				}
									
				if((this.person.messagingRingtoneLoc != undefined) && (this.person.messagingRingtoneLoc != "")) {
					this.modelMsgtone.value = this.person.messagingRingtoneName;
					
					this.controller.modelChanged(this.modelMsgtone, this);
				}
			}.bind(this) });
	},
	
	saveContactPreferences: function() {
		if(!this.contactPrefs)
			AppAssistant.contactsService.setPersonDetails(this.controller, this.person.id, this.person);
		else {
			var contactPrefs = {};
			
			var prefs = {};
			
			if((!this.modelBlockedContacts.value) && (!this.modelUnknownContacts.value))
				this.controller.get("UnknownSettingsGroup").hide();
			else
				this.controller.get("UnknownSettingsGroup").show();

			if(this.modelCallAction.value != "nothing")
				prefs.ringtoneLoc = this.modelCallAction.value;
			else if(this.modelRingtone.value != "default") {
				prefs.ringtoneLoc = this.person.ringtoneLoc;
				prefs.ringtoneName = this.person.ringtoneName;
			}
			
			if(this.modelMsgtone.value != "default") {
				prefs.messagingRingtoneLoc = this.person.messagingRingtoneLoc;
				prefs.messagingRingtoneName = this.person.messagingRingtoneName;
			}
			
			if(this.modelBlockedContacts.value)
				contactPrefs.blocked = prefs;
			
			if(this.modelUnknownContacts.value)
				contactPrefs.unknown = prefs;

			this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
				method: 'setPreferences', parameters: {'contactPrefs': contactPrefs} });
		}
	},

	setCallAction: function(event) {
		if(this.modelCallAction.value != "nothing") {
			this.controller.get("CallActionRow").addClassName("single");
			this.controller.get("CallActionRow").removeClassName("first");			
			this.controller.get("RingtoneRow").hide();

			this.person.dirty = true;
			this.person.ringtoneLoc = this.modelCallAction.value;
			this.person.ringtoneName = "";
		}
		else {
			this.modelRingtone.value = "default";
			this.controller.modelChanged(this.modelRingtone);

			this.controller.get("CallActionRow").addClassName("first");			
			this.controller.get("CallActionRow").removeClassName("single");
			this.controller.get("RingtoneRow").show();			

			this.person.dirty = true;
			this.person.ringtoneLoc = "";
			this.person.ringtoneName = "";
		}
		
		this.saveContactPreferences();
	},
	
	selectRingtone: function(event) {
		if(event.value == "default") {
			this.person.dirty = true;
			this.person.ringtoneLoc = "";
			this.person.ringtoneName = "";
		
			this.saveContactPreferences();
		}
		else {
			if((this.person.ringtoneName) && (this.person.ringtoneName != ""))
				this.modelRingtone.value = this.person.ringtoneName;
			else
				this.modelRingtone.value = "default";

			this.controller.modelChanged(this.modelRingtone);

			Mojo.FilePicker.pickFile({actionType: 'attach', kinds: ['ringtone'], defaultKind: 'ringtone',
				filePath:this.person.ringtoneLoc, onSelect: this.setRingtone.bind(this)}, 
				this.controller.stageController);
		}
	},

	setRingtone: function(file) {
		var ringtonePath = file.fullPath.replace(/^\s*/, '').replace(/\s*$/, '');
		if(ringtonePath.indexOf("file://") == 0) 
			ringtonePath = ringtonePath.substring(7);

		this.person.dirty = true;
		this.person.ringtoneName = file.name;
		this.person.ringtoneLoc = ringtonePath;

		this.modelRingtone.value = file.name;
		
		this.controller.modelChanged(this.modelRingtone);
		
		this.saveContactPreferences();
	},
	
	selectMsgtone: function(event) {
		if(event.value == "default") {
			this.person.dirty = true;
			this.person.messagingRingtoneLoc = "";
			this.person.messagingRingtoneName = "";
			
			this.saveContactPreferences();
		}
		else {
			if((this.person.messagingRingtoneName) && (this.person.messagingRingtoneName != ""))
				this.modelMsgtone.value = this.person.messagingRingtoneName;
			else
				this.modelMsgtone.value = "default";

			this.controller.modelChanged(this.modelMsgtone);
				
			Mojo.FilePicker.pickFile({actionType: 'attach', kinds: ['ringtone'], defaultKind: 'ringtone',
				filePath:this.person.messagingRingtoneLoc, onSelect: this.setMsgtone.bind(this)}, 
				this.controller.stageController);
		}
	},

	setMsgtone: function(file) {
		var ringtonePath = file.fullPath.replace(/^\s*/, '').replace(/\s*$/, '');
		if(ringtonePath.indexOf("file://") == 0) 
			ringtonePath = ringtonePath.substring(7);

		this.person.dirty = true;
		this.person.messagingRingtoneName = file.name;
		this.person.messagingRingtoneLoc = ringtonePath;

		this.modelMsgtone.value = file.name;
		
		this.controller.modelChanged(this.modelMsgtone);

		this.saveContactPreferences();		
	},

	cleanup: function() {
	}
});

