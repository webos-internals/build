var LunaControlAssistant = function(){
}
  
LunaControlAssistant.prototype.run = function(future) {  
	if(this.controller.args.action == "restart") {
	  var Exec = IMPORTS.require('child_process').exec;

		var options = {
			cwd: null,
			env: null,
  	  timeout: 0,
			ecoding: "utf8",
  	  maxBuffer: 1024,
  	  killSignal: "SIGTERM"
		};

		Exec("/usr/bin/pkill LunaSysMgr", options, this.handleExecute.bind(this, future));
	}
	else
		future.result = { returnValue: false };
}

LunaControlAssistant.prototype.handleExecute = function(future, error) { 
   future.result = { returnValue: true };
}
